// Imaan Vocab Game settings. Open README.md for the 5-minute setup.
window.IMAAN_CONFIG = {
  // Paste your Google Apps Script "Web app" URL between the quotes (it ends with /exec).
  // Leave it empty and the game still works, it just does not send results to teachers.
  trackerUrl: ""
};
